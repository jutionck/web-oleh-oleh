<div class="container mt-5">
  <div class="alert alert-success">
    <h4 class="alert-heading">Order Successful!</h4>
    <p>Your order has been placed successfully. Thank you for shopping with us.</p>
    <hr>
    <a href="<?= site_url('order/history') ?>" class="btn btn-primary">Lihat Riwayat Pemesanan</a>
  </div>
</div>