<?php
defined('BASEPATH') or exit('No direct script access allowed');

$autoload['packages'] = array();
$autoload['libraries'] = array('session', 'encryption', 'form_validation', 'email', 'upload', 'user_agent', 'database', 'ciqrcode');
$autoload['drivers'] = array();
$autoload['helper'] = array('url', 'berkarya', 'text', 'download', 'file');
$autoload['config'] = array();
$autoload['language'] = array();
$autoload['model'] = array();
