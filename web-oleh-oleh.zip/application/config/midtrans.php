<?php

defined('BASEPATH') or exit('No direct script access allowed');

$config['midtrans_server_key'] = 'SB-Mid-server-k14J56HrRx3PT4fIiCU_FrLi';
$config['midtrans_client_key'] = 'SB-Mid-client-txTPsq3JcRYcOoBt';
$config['midtrans_is_production'] = false;
$config['midtrans_is_sanitized'] = true;
$config['midtrans_is_3ds'] = true;
